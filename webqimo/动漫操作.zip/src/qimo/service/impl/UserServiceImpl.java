package qimo.service.impl;

import qimo.model.User;
import qimo.service.UserService;

public class UserServiceImpl implements UserService {
    @Override
    public User selectByUserId(int id) {
        return null;
    }
}
