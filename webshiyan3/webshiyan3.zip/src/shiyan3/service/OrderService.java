package shiyan3.service;

import shiyan3.pojo.Order;

public interface OrderService {
    int addorder(Order order);
}
