package shiyan3.dao;

import shiyan3.pojo.Order;

public interface OrderDao {
    int addOrder(Order order);
}
