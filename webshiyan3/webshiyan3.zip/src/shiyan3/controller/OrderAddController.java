package shiyan3.controller;

import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
@WebServlet("/order/add")
public class OrderAddController extends HttpServlet {

}
